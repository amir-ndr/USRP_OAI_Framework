# Experiment report

**RFSIM — MEASURED INPUT — VALIDITY DEPENDS ON CAPTURE AND EVENT EVIDENCE**

| Metric | Value |
|---|---|
| sent_records | 1939 |
| received | 1939 |
| lost | 0 |
| censored | 0 |
| loss_fraction | 0.0 |
| rtt_median_ms | 5.680084228515625 |
| rtt_p95_ms | 6.619930267333984 |
| max_interarrival_gap_ms | 31.001088 |
| probe_interval_s | 0.02 |
| attempts | 0 |
| complete | 0 |
| failed | 0 |
| unknown | 0 |
| success_fraction_known_outcomes | None |
| wilson95_known_outcomes | None |
| duration_median_ms | None |
| duration_p95_ms | None |
| pingpong_reverse_transitions_5s | 0 |
| window_max_gap_median_ms | None |
| traffic_windows_complete | 0 |
| traffic_windows_partial_or_censored | 0 |
| traffic_windows_uncovered | 0 |
| window_lost_total | None |

## Interpretation boundaries

- Traffic metrics cover the complete probe interval; they are not automatically attributed to handover.
- Interarrival gaps include normal packet spacing, scheduling and network delay; not exact radio interruption.
- Signaling duration depends on your explicitly selected event boundaries and timestamp accuracy.
- Unknown HO outcomes are excluded from the known-outcome success fraction and must be reported.
- Per-handover windows span attempt-1 s to completion+2 s and need probe and events on the same host clock; aggregate window metrics exclude partial/censored windows.
- Experiment mode is supplied by the operator/config, not inferred from packets; synthetic=false does not prove real RF.
