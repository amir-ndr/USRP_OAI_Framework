# Run summary: exp2_ota_handover

RFSIM / ota - n78_24prb_30khz, DL 3604.8 MHz, UL 3604.8 MHz - cells ['du0'] - UHD TX gain du0 0.5 dB

| Result | Check | What it means |
|---|---|---|
| **PASS** | UE attached | PDU session up (oaitun_ue1 10.0.0.2) 2.5 s after the UE started |
| **PASS** | Traffic through the radio link | 1939/1939 probes answered (0.00 % lost); RTT median 5.7 ms, p95 6.6 ms; longest gap 31 ms |
| **PASS** | Run ended cleanly | all processes stopped in order (UE, DUs, CU) |

Files: config.yaml (exact configuration), *.console (live output), logs/ (timestamped JSONL), packets.jsonl, trigger.jsonl, events.csv, report/report.html.
