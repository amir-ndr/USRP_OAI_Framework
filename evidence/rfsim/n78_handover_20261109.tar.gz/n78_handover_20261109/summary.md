# Run summary: exp2_ota_handover

RFSIM / ota - n78_24prb_30khz, DL 3604.8 MHz, UL 3604.8 MHz - cells ['du0', 'du1'] - UHD TX gain du0 0.5 dB, du1 0.5 dB

| Result | Check | What it means |
|---|---|---|
| **PASS** | UE attached | PDU session up (oaitun_ue1 10.0.0.2) 2.0 s after the UE started |
| **PASS** | Traffic through the radio link | 4820/4820 probes answered (0.00 % lost); RTT median 6.7 ms, p95 8.3 ms; longest gap 40 ms |
| **PASS** | Manual handovers | 4 of 4 triggers completed; signalling median 38.5 ms; typical traffic interruption (largest gap per handover, median) 38 ms |
| **PASS** | Run ended cleanly | all processes stopped in order (UE, DUs, CU) |

| # | from -> to | outcome | signalling ms | lost probes | largest gap ms |
|---|---|---|---:|---:|---:|
| ho1 | PCI 0 -> 1 | complete | 38.1 | 0 | 39.82281684875488 |
| ho2 | PCI 1 -> 0 | complete | 39.0 | 0 | 29.49810028076172 |
| ho3 | PCI 0 -> 1 | complete | 38.9 | 0 | 40.14182090759277 |
| ho4 | PCI 1 -> 0 | complete | 34.3 | 0 | 36.40007972717285 |

Files: config.yaml (exact configuration), *.console (live output), logs/ (timestamped JSONL), packets.jsonl, trigger.jsonl, events.csv, report/report.html.
