# Experiment report

**RFSIM — MEASURED INPUT — VALIDITY DEPENDS ON CAPTURE AND EVENT EVIDENCE**

| Metric | Value |
|---|---|
| sent_records | 4820 |
| received | 4820 |
| lost | 0 |
| censored | 0 |
| loss_fraction | 0.0 |
| rtt_median_ms | 6.710052490234375 |
| rtt_p95_ms | 8.340382575988771 |
| max_interarrival_gap_ms | 40.141824 |
| probe_interval_s | 0.02 |
| attempts | 4 |
| complete | 4 |
| failed | 0 |
| unknown | 0 |
| success_fraction_known_outcomes | 1.0 |
| wilson95_known_outcomes | [0.5101091635454165, 1] |
| duration_median_ms | 38.50996494293213 |
| duration_p95_ms | 38.99414539337158 |
| pingpong_reverse_transitions_5s | 0 |
| window_max_gap_median_ms | 38.11144828796387 |
| traffic_windows_complete | 4 |
| traffic_windows_partial_or_censored | 0 |
| traffic_windows_uncovered | 0 |
| window_lost_total | 0 |

## Handovers

| id | source→target | outcome | signaling ms | window lost | window max gap ms |
|---|---|---|---:|---:|---:|
| ho1 | 0→1 | complete | 38.14291954040527 | 0 | 39.82281684875488 |
| ho2 | 1→0 | complete | 39.01481628417969 | 0 | 29.49810028076172 |
| ho3 | 0→1 | complete | 38.877010345458984 | 0 | 40.14182090759277 |
| ho4 | 1→0 | complete | 34.303903579711914 | 0 | 36.40007972717285 |

## Interpretation boundaries

- Traffic metrics cover the complete probe interval; they are not automatically attributed to handover.
- Interarrival gaps include normal packet spacing, scheduling and network delay; not exact radio interruption.
- Signaling duration depends on your explicitly selected event boundaries and timestamp accuracy.
- Unknown HO outcomes are excluded from the known-outcome success fraction and must be reported.
- Per-handover windows span attempt-1 s to completion+2 s and need probe and events on the same host clock; aggregate window metrics exclude partial/censored windows.
- Experiment mode is supplied by the operator/config, not inferred from packets; synthetic=false does not prove real RF.
