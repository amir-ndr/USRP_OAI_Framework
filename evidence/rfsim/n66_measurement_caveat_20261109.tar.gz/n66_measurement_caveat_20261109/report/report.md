# Experiment report

**RFSIM — MEASURED INPUT — VALIDITY DEPENDS ON CAPTURE AND EVENT EVIDENCE**

| Metric | Value |
|---|---|
| sent_records | 2749 |
| received | 2749 |
| lost | 0 |
| censored | 0 |
| loss_fraction | 0.0 |
| rtt_median_ms | 6.3800811767578125 |
| rtt_p95_ms | 12.060022354125968 |
| max_interarrival_gap_ms | 76.226048 |
| probe_interval_s | 0.02 |
| attempts | 2 |
| complete | 2 |
| failed | 0 |
| unknown | 0 |
| success_fraction_known_outcomes | 1.0 |
| wilson95_known_outcomes | [0.34238022750666547, 1] |
| duration_median_ms | 32.88304805755615 |
| duration_p95_ms | 33.61293077468872 |
| pingpong_reverse_transitions_5s | 0 |
| window_max_gap_median_ms | 54.80396747589111 |
| traffic_windows_complete | 2 |
| traffic_windows_partial_or_censored | 0 |
| traffic_windows_uncovered | 0 |
| window_lost_total | 0 |

## Handovers

| id | source→target | outcome | signaling ms | window lost | window max gap ms |
|---|---|---|---:|---:|---:|
| ho1 | 0→1 | complete | 32.07206726074219 | 0 | 33.38193893432617 |
| ho2 | 1→0 | complete | 33.69402885437012 | 0 | 76.22599601745605 |

## Interpretation boundaries

- Traffic metrics cover the complete probe interval; they are not automatically attributed to handover.
- Interarrival gaps include normal packet spacing, scheduling and network delay; not exact radio interruption.
- Signaling duration depends on your explicitly selected event boundaries and timestamp accuracy.
- Unknown HO outcomes are excluded from the known-outcome success fraction and must be reported.
- Per-handover windows span attempt-1 s to completion+2 s and need probe and events on the same host clock; aggregate window metrics exclude partial/censored windows.
- Experiment mode is supplied by the operator/config, not inferred from packets; synthetic=false does not prove real RF.
